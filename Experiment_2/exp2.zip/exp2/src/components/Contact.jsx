import RatingComponent from './Rating';

export default function Contact() {
  return (
    <div>
      <h2>Contact Page</h2>
      <RatingComponent />
    </div>
  );
}