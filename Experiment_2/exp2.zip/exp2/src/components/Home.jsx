import ButtonBasic from './Button.jsx';
export default function Home() {
    return (
        <div>
            <h2>Home Page</h2>
            <ButtonBasic />
        </div>
    );
}